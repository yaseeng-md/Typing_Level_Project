from django.shortcuts import render

def home(request):
    return render(request,'html/home.html')

def easy(request):
    return render(request,'html/easy.html')

def medium(request):
    return render(request,'html/medium.html')

def hard(request):
    return render(request,'html/hard.html')