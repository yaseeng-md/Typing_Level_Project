from django.urls import path
from.import views

urlpatterns = [
    path("",views.home,name='home'),
    path("easy/",views.easy,name='easy'),
    path("hard/",views.hard,name = "hard"),
    path("medium/",views.medium,name = "medium"),
    
]